package com.example.services;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.example.model.Airlines;
import com.example.model.Flights;
import com.example.model.Login;
import com.example.model.Places;
import com.hibernate.config.HibernateCnfig;



public class FlyawayService {
	
	SessionFactory sf=null;
	
	public FlyawayService() {
		
		sf=HibernateCnfig.getSessionFactory();
	}

	public void addnewPlaces(Places places) {
		
		Session session=sf.openSession();
		Transaction trans=session.beginTransaction();
		session.save(places);
		trans.commit();
		session.close();
		
	}
	
public void addnewAirlines(Airlines air) {
		
		Session session=sf.openSession();
		Transaction trans=session.beginTransaction();
		session.save(air);
		trans.commit();
		session.close();
		
	}
public void addnewFlights(Flights fly) {
	
	Session session=sf.openSession();
	Transaction trans=session.beginTransaction();
	session.save(fly);
	trans.commit();
	session.close();
	
}

	public List<Places> showAll(){
		
		Session session=sf.openSession();
		TypedQuery qry=session.createQuery("from Places");
		List<Places> pall=qry.getResultList();
		return pall;
		
	}
public List<Airlines> showAll1(){
		
		Session session=sf.openSession();
		TypedQuery qry=session.createQuery("from Airlines");
		List<Airlines> aall=qry.getResultList();
		return aall;
		
	}
public List<Flights> showAll2(){
	
	Session session=sf.openSession();
	TypedQuery qry=session.createQuery("from Flights");
	List<Flights> fall=qry.getResultList();
	return fall;
	
}
public Flights searchFlight(String source,String destination) {
	
	Session session=sf.openSession();
	TypedQuery qry=session.createQuery("from Flights where source=:dept and destination=:arriv");
	qry.setParameter("dept",source);
	qry.setParameter("arriv", destination);
	List<Flights> fall=qry.getResultList();
	if(fall.isEmpty())
		return null;
	
	return fall.get(0);
	
}
public Login loginDetails(String oldpswd) {
	Session session=sf.openSession();
	Login l=new Login();
	TypedQuery qry=session.createQuery("from Login where password=:pswd");
	qry.setParameter("pswd",oldpswd);
	List<Login> up=qry.getResultList();
	if(up.isEmpty())
		return null;
	return up.get(0);
}
public String changePswd(Login lo) {
	String res="err";
	Session session=sf.openSession();
	Transaction trans=session.beginTransaction();
	TypedQuery qry=session.createQuery("update Login set password=:pass where username=:uname");
	qry.setParameter("uname",lo.getUsername());
	qry.setParameter("pass",lo.getPassword());
	int r1=qry.executeUpdate();
	trans.commit();
	if(r1>=1)
		res=" password change Successfully";		
	return res;	
}
public List<Login> loginInfo() {
	Session session=sf.openSession();
	TypedQuery qry=session.createQuery("from Login ");
	List<Login> up=qry.getResultList();
		return up;
}
}
