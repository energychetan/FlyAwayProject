package com.example.model;


import com.example.model.Places;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernate.config.HibernateCnfig;

public class HibernateTest {

    public static void main(String[] args) {
        // Initialize the SessionFactory
        SessionFactory sessionFactory = HibernateCnfig.getSessionFactory();
        
        try {
            // Open a session
            Session session = sessionFactory.openSession();
            
            // Perform a database operation (e.g., retrieve a list of Places)
            session.beginTransaction();
            List<Places> placesList = session.createQuery("from Places", Places.class).getResultList();
            session.getTransaction().commit();
            
            // Print the retrieved entities
            for (Places place : placesList) {
                System.out.println("Place Name: " + place.getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the SessionFactory when done
            sessionFactory.close();
        }
    }
}
