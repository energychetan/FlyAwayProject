package com.hibernate.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.model.Airlines;
import com.example.model.Places;
import com.example.services.FlyawayService;


/**
 * Servlet implementation class AddCustomer
 */
@WebServlet("/AddAirlines")
public class AddAirlines extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAirlines() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String aid=request.getParameter("txtAid");
		String aname=request.getParameter("txtAname");
		
		Airlines air=new Airlines();
		FlyawayService fs=new FlyawayService();
		air.setCode(aid);
		air.setName(aname);
		fs.addnewAirlines(air);
		response.sendRedirect("AddAirlines.jsp");

	
	}

}
