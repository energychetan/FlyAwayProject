package com.hibernate.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.model.Places;
import com.example.services.FlyawayService;


/**
 * Servlet implementation class AddCustomer
 */
@WebServlet("/AddPlaces")
public class AddPlaces extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPlaces() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String pid=request.getParameter("txtPid");
		String pname=request.getParameter("txtPname");
		
		Places place=new Places();
		FlyawayService fs=new FlyawayService();
		place.setCode(pid);
		place.setName(pname);
		fs.addnewPlaces(place);
		response.sendRedirect("AddPlaces.jsp");

	
	}

}
